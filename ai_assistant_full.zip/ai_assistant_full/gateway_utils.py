"""
╔══════════════════════════════════════════════════════════════════╗
║  gateway_utils.py  —  AgentCore Gateway tool loader              ║
╠══════════════════════════════════════════════════════════════════╣
║  Lets the AutoGen agent call tools that live BEHIND an AgentCore ║
║  Gateway — for example, a Lambda function, an internal REST API, ║
║  or a pre-built connector — without writing custom integration   ║
║  code for each one.                                              ║
╚══════════════════════════════════════════════════════════════════╝

WHAT GATEWAY ADDS
  The agent already has an in-process web_search tool (agent.py).
  Gateway is a different pattern: instead of writing the tool logic
  directly in Python, you point Gateway at an existing Lambda
  function (or API), and Gateway automatically exposes it to the
  agent as an MCP-compatible tool — no custom client code per API.

  In this project, Gateway is wired up to call the sample Lambda
  function in lambda/search_lambda.py, giving a second, AWS-hosted
  route to live internet search, alongside the built-in one.

HOW AUTHENTICATION WORKS
  Gateway requires inbound requests to present a JWT bearer token.
  This project uses an Amazon Cognito user pool (created by
  setup_gateway.ps1) as the token issuer. get_gateway_token() below
  signs in a machine user with Cognito and returns a short-lived
  access token to attach to each MCP request.

REQUIRED ENVIRONMENT VARIABLES
  GATEWAY_URL                 MCP endpoint URL for your Gateway
  GATEWAY_COGNITO_USER_POOL_ID
  GATEWAY_COGNITO_CLIENT_ID
  GATEWAY_COGNITO_USERNAME
  GATEWAY_COGNITO_PASSWORD

  If GATEWAY_URL is not set, load_gateway_tools() returns an empty
  list and the agent runs fine without it — Gateway is optional.
"""

import logging
import os

import boto3
from botocore.exceptions import ClientError

log = logging.getLogger("gateway_utils")

REGION = os.environ.get("AWS_REGION", "us-east-1")

GATEWAY_URL          = os.environ.get("GATEWAY_URL", "")
COGNITO_USER_POOL_ID = os.environ.get("GATEWAY_COGNITO_USER_POOL_ID", "")
COGNITO_CLIENT_ID    = os.environ.get("GATEWAY_COGNITO_CLIENT_ID", "")
COGNITO_USERNAME     = os.environ.get("GATEWAY_COGNITO_USERNAME", "")
COGNITO_PASSWORD     = os.environ.get("GATEWAY_COGNITO_PASSWORD", "")


def gateway_enabled() -> bool:
    """Return True if Gateway has been configured for this deployment."""
    return bool(GATEWAY_URL)


def get_gateway_token() -> str | None:
    """Sign in to Cognito and return a bearer token for calling Gateway.

    Returns None (and logs a warning) if Cognito is not configured or
    the sign-in fails — callers should treat that as "Gateway unavailable".
    """
    if not (COGNITO_USER_POOL_ID and COGNITO_CLIENT_ID and COGNITO_USERNAME and COGNITO_PASSWORD):
        log.warning("Gateway Cognito credentials are not fully configured.")
        return None

    try:
        idp = boto3.client("cognito-idp", region_name=REGION)
        resp = idp.initiate_auth(
            ClientId=COGNITO_CLIENT_ID,
            AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters={
                "USERNAME": COGNITO_USERNAME,
                "PASSWORD": COGNITO_PASSWORD,
            },
        )
        return resp["AuthenticationResult"]["AccessToken"]
    except ClientError as exc:
        log.warning("Could not obtain Gateway token from Cognito: %s", exc)
        return None
    except Exception as exc:
        log.warning("Unexpected error obtaining Gateway token: %s", exc)
        return None


async def load_gateway_tools() -> list:
    """Return a list of AutoGen-compatible tools backed by AgentCore Gateway.

    Uses AutoGen's MCP tool adapter (autogen_ext.tools.mcp) to connect to
    the Gateway's MCP endpoint over Streamable HTTP and discover whatever
    tools the Gateway currently exposes (e.g. the search Lambda target
    configured by setup_gateway.ps1).

    Returns an empty list if Gateway is not configured, or if the
    connection/auth fails — this makes Gateway a fully optional add-on.
    """
    if not gateway_enabled():
        log.info("GATEWAY_URL not set — skipping Gateway tools (optional).")
        return []

    token = get_gateway_token()
    if not token:
        log.warning("No Gateway token available — skipping Gateway tools.")
        return []

    try:
        # AutoGen's MCP extension — requires:  pip install "autogen-ext[mcp]"
        from autogen_ext.tools.mcp import StreamableHttpServerParams, mcp_server_tools

        server_params = StreamableHttpServerParams(
            url=GATEWAY_URL,
            headers={"Authorization": f"Bearer {token}"},
        )
        tools = await mcp_server_tools(server_params)
        log.info("Loaded %d tool(s) from AgentCore Gateway.", len(tools))
        return tools

    except ImportError:
        log.warning(
            "autogen-ext[mcp] is not installed — run: "
            "pip install \"autogen-ext[mcp]\"  to enable Gateway tools."
        )
        return []
    except Exception as exc:
        log.warning("Could not load Gateway tools: %s", exc)
        return []
