"""
╔══════════════════════════════════════════════════════════════════╗
║  guardrail_utils.py  —  Policy / Guardrails enforcement          ║
╠══════════════════════════════════════════════════════════════════╣
║  Adds a safety and compliance layer around the agent using       ║
║  Amazon Bedrock Guardrails — independent of the AutoGen          ║
║  reasoning loop and independent of Claude's own judgement.       ║
╚══════════════════════════════════════════════════════════════════╝

WHAT THIS ADDS
  Even a well-instructed agent can be pushed, by a user or by a
  poorly-worded search result, toward content a business does not
  want it producing (certain topics, PII exposure, prompt-injection
  style instructions embedded in a webpage, etc).

  A Guardrail is a policy configured once, centrally, in Bedrock —
  denied topics, blocked words, PII redaction, and content filters —
  and enforced by calling the ApplyGuardrail API directly. This file
  applies the guardrail TWICE per request:

    1. To the INCOMING user prompt, before it ever reaches the agent.
    2. To the OUTGOING agent answer, before it is returned to the user.

  This means the guardrail is enforced even if the agent itself
  never "decides" to follow the policy — it is checked independently,
  the same way a compliance filter would sit in front of and behind
  any production chatbot.

REQUIRED ENVIRONMENT VARIABLES
  GUARDRAIL_ID          The Guardrail resource ID (setup_guardrail.ps1)
  GUARDRAIL_VERSION      Usually "DRAFT" while testing, or a published
                         numbered version once promoted to production

  If GUARDRAIL_ID is not set, check_text() always returns "ALLOWED" —
  Guardrails is a fully optional add-on, exactly like the others.
"""

import logging
import os

import boto3
from botocore.exceptions import ClientError

log = logging.getLogger("guardrail_utils")

REGION            = os.environ.get("AWS_REGION", "us-east-1")
GUARDRAIL_ID      = os.environ.get("GUARDRAIL_ID", "")
GUARDRAIL_VERSION = os.environ.get("GUARDRAIL_VERSION", "DRAFT")

_client = None


def _get_client():
    global _client
    if _client is None:
        _client = boto3.client("bedrock-runtime", region_name=REGION)
    return _client


def guardrail_enabled() -> bool:
    """Return True if a Guardrail resource has been configured."""
    return bool(GUARDRAIL_ID)


class GuardrailResult:
    """Simple result object returned by check_text()."""

    def __init__(self, allowed: bool, reason: str = "", filtered_text: str = ""):
        self.allowed = allowed
        self.reason = reason
        self.filtered_text = filtered_text


def check_text(text: str, source: str) -> GuardrailResult:
    """Run text through the configured Bedrock Guardrail.

    Args:
        text:   The text to check (user prompt or agent answer).
        source: "INPUT" for user-authored text, "OUTPUT" for
                model/agent-authored text — Guardrails applies
                slightly different rules depending on which.

    Returns:
        GuardrailResult with allowed=True if the text passed, or
        allowed=False with a human-readable reason if it was blocked.
        If Guardrails is not configured, always returns allowed=True.
    """
    if not guardrail_enabled():
        return GuardrailResult(allowed=True)

    client = _get_client()

    try:
        resp = client.apply_guardrail(
            guardrailIdentifier=GUARDRAIL_ID,
            guardrailVersion=GUARDRAIL_VERSION,
            source=source,  # "INPUT" or "OUTPUT"
            content=[{"text": {"text": text}}],
        )

        action = resp.get("action", "NONE")

        if action == "GUARDRAIL_INTERVENED":
            # Collect a human-readable reason from whichever policy fired
            reasons = []
            assessments = resp.get("assessments", [])
            for a in assessments:
                if "topicPolicy" in a:
                    for t in a["topicPolicy"].get("topics", []):
                        if t.get("action") == "BLOCKED":
                            reasons.append(f"blocked topic: {t.get('name')}")
                if "contentPolicy" in a:
                    for f in a["contentPolicy"].get("filters", []):
                        if f.get("action") == "BLOCKED":
                            reasons.append(f"content filter: {f.get('type')}")
                if "sensitiveInformationPolicy" in a:
                    for p in a["sensitiveInformationPolicy"].get("piiEntities", []):
                        if p.get("action") == "BLOCKED":
                            reasons.append(f"PII detected: {p.get('type')}")

            reason_text = "; ".join(reasons) if reasons else "policy violation"
            log.warning("Guardrail blocked %s text: %s", source, reason_text)

            outputs = resp.get("outputs", [])
            filtered = outputs[0]["text"] if outputs else ""

            return GuardrailResult(allowed=False, reason=reason_text, filtered_text=filtered)

        return GuardrailResult(allowed=True)

    except ClientError as exc:
        log.warning("Guardrail check failed (allowing by default): %s", exc)
        return GuardrailResult(allowed=True)
    except Exception as exc:
        log.warning("Unexpected error during guardrail check: %s", exc)
        return GuardrailResult(allowed=True)
